Platform configurations for RIOT-OS
====================================
This directory contains existing configuration and initialization files for platforms supported by RIOT-OS.
