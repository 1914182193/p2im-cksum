# Translation
If you would like to contribute a translation, look at the file `translation.c` in the source code.
Currently translations are compiled in at compile time with #defines (nothing complex).
So all you need to do is add another section formatted like the english one that is there and either create a pull request or a github issue for inclusion.
If the glyphs required already exist in the fonts then support should be quick. Otherwise it may take longer for the fonts to be created.